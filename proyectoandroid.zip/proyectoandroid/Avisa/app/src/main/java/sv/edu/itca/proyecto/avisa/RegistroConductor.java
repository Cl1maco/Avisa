package sv.edu.itca.proyecto.avisa;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroConductor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_conductor);
    }
}
